$('#testimonials').parallax("50%", 0.1);

$(".main-menu").sticky({topSpacing:0});

new WOW().init();